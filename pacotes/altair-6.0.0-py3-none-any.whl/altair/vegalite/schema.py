"""Altair schema wrappers."""

# ruff: noqa: F403
from .v6.schema import *
